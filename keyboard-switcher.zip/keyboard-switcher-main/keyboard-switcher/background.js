chrome.commands.onCommand.addListener((command) => {
  if (command === "toggle-switcher") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0] && tabs[0].id) {
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggle_language" })
          .catch((err) => {
            // ป้องกัน Error กรณีหน้าเว็บไม่รองรับ (เช่น chrome:// หรือ New Tab)
            console.log("Cannot run script on this page:", err);
          });
      }
    });
  }
});