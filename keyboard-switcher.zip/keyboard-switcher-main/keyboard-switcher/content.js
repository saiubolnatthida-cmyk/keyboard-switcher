const enToTh = {
  '`':'-', '~':'%',
  '1':'ๅ', '!':'+',
  '2':'/', '@':'๑',
  '3':'_', '#':'๒',
  '4':'ภ', '$':'๓',
  '5':'ถ', '%':'๔',
  '6':'ุ', '^':'ู',
  '7':'ึ', '&':'฿',
  '8':'ค', '*':'๕',
  '9':'ต', '(':'๖',
  '0':'จ', ')':'๗',
  '-':'ข', '_':'๘',
  '=':'ช', '+':'๙',

  'q':'ๆ', 'Q':'๐',
  'w':'ไ', 'W':'"',
  'e':'ำ', 'E':'ฎ',
  'r':'พ', 'R':'ฑ',
  't':'ะ', 'T':'ธ',
  'y':'ั', 'Y':'ํ',
  'u':'ี', 'U':'๊',
  'i':'ร', 'I':'ณ',
  'o':'น', 'O':'ฯ',
  'p':'ย', 'P':'ญ',
  '[':'บ', '{':'ฐ',
  ']':'ล', '}':',',
  '\\':'ฃ', '|':'ฅ',

  'a':'ฟ', 'A':'ฤ',
  's':'ห', 'S':'ฆ',
  'd':'ก', 'D':'ฏ',
  'f':'ด', 'F':'โ',
  'g':'เ', 'G':'ฌ',
  'h':'้', 'H':'็',
  'j':'่', 'J':'๋',
  'k':'า', 'K':'ษ',
  'l':'ส', 'L':'ศ',
  ';':'ว', ':':'ซ',
  '\'':'ง', '"':'.',

  'z':'ผ', 'Z':'(',
  'x':'ป', 'X':')',
  'c':'แ', 'C':'ฉ',
  'v':'อ', 'V':'ฮ',
  'b':'ิ', 'B':'ฺ',
  'n':'ื', 'N':'์',
  'm':'ท', 'M':'?',
  ',':'ม', '<':'ฒ',
  '.':'ใ', '>':'ฬ',
  '/':'ฝ', '?':'ฦ'
};

// สร้างตารางย้อนกลับ TH -> EN
const thToEn = {};
for (let key in enToTh) {
  thToEn[enToTh[key]] = key;
}

// ฟังก์ชันแปลงข้อความ
function convertText(str) {
  return str.split('').map(char => {
    if (enToTh[char]) return enToTh[char];
    if (thToEn[char]) return thToEn[char];
    return char;
  }).join('');
}

// รับข้อความเปลี่ยนภาษาเมื่อกด Shortcut
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "toggle_language") {
    replaceSelectedText();
  }
});

function replaceSelectedText() {
  const activeEl = document.activeElement;

  // 1. ช่องพิมพ์ปกติ (<input> หรือ <textarea>)
  if (activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA')) {
    const start = activeEl.selectionStart;
    const end = activeEl.selectionEnd;
    const selectedText = activeEl.value.substring(start, end);

    if (selectedText) {
      const converted = convertText(selectedText);
      activeEl.value = activeEl.value.substring(0, start) + converted + activeEl.value.substring(end);
      activeEl.setSelectionRange(start, start + converted.length);
      activeEl.dispatchEvent(new Event('input', { bubbles: true }));
    }
  } 
  // 2. ช่องพิมพ์แบบ Rich Text / contenteditable (เช่น Gemini, ChatGPT, Facebook)
  else {
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const selectedText = selection.toString();
      if (selectedText) {
        const converted = convertText(selectedText);
        
        // ใช้ execCommand เพื่อให้ Framework ของเว็บรับรู้การแก้ไขข้อความ
        if (!document.execCommand('insertText', false, converted)) {
          const range = selection.getRangeAt(0);
          range.deleteContents();
          range.insertNode(document.createTextNode(converted));
        }
      }
    }
  }
}