const enToTh = {
  '`':'-', '~':'%',
  '1':'ๅ', '!':'+',
  '2':'/', '@':'๑',
  '3':'_', '#':'๒',
  '4':'ภ', '$':'๓',
  '5':'ถ', '%':'๔',
  '6':'ุ', '^':'ู',
  '7':'ึ', '&':'฿',
  '8':'ค', '*':'๕',
  '9':'ต', '(':'๖',
  '0':'จ', ')':'๗',
  '-':'ข', '_':'๘',
  '=':'ช', '+':'๙',

  'q':'ๆ', 'Q':'๐',
  'w':'ไ', 'W':'"',
  'e':'ำ', 'E':'ฎ',
  'r':'พ', 'R':'ฑ',
  't':'ะ', 'T':'ธ',
  'y':'ั', 'Y':'ํ',
  'u':'ี', 'U':'๊',
  'i':'ร', 'I':'ณ',
  'o':'น', 'O':'ฯ',
  'p':'ย', 'P':'ญ',
  '[':'บ', '{':'ฐ',
  ']':'ล', '}':',',
  '\\':'ฃ', '|':'ฅ',

  'a':'ฟ', 'A':'ฤ',
  's':'ห', 'S':'ฆ',
  'd':'ก', 'D':'ฏ',
  'f':'ด', 'F':'โ',
  'g':'เ', 'G':'ฌ',
  'h':'้', 'H':'็',
  'j':'่', 'J':'๋',
  'k':'า', 'K':'ษ',
  'l':'ส', 'L':'ศ',
  ';':'ว', ':':'ซ',
  '\'':'ง', '"':'.',

  'z':'ผ', 'Z':'(',
  'x':'ป', 'X':')',
  'c':'แ', 'C':'ฉ',
  'v':'อ', 'V':'ฮ',
  'b':'ิ', 'B':'ฺ',
  'n':'ื', 'N':'์',
  'm':'ท', 'M':'?',
  ',':'ม', '<':'ฒ',
  '.':'ใ', '>':'ฬ',
  '/':'ฝ', '?':'ฦ'
};

const thToEn = {};
for (let key in enToTh) { thToEn[enToTh[key]] = key; }

let thaiDict = new Set();

const englishDict = [
  "hello", "noted", "segment", "good", "statement", "afternoon", "evening", "welcome", 
  "please", "thank", "thanks", "thankfully", "sorry", "apologize", "apologies",
  "how", "can", "help", "assist", "assistance", "support", "service", "check", 
  "verify", "confirm", "update", "change", "cancel", "submit", "request", "process", 
  "proceed", "receive", "send", "inform", "contact", "reach", "attach", "download",
  "you", "your", "yours", "customer", "client", "account", "user", "username", 
  "email", "phone", "number", "address", "profile", "status", "pending", "approved", 
  "rejected", "document", "file", "information", "detail", "details", "system",
  "money", "amount", "balance", "deposit", "withdraw", "withdrawal", "transfer", 
  "transaction", "bank", "credit", "THB", "fee", "rate", "currency", "crypto", 
  "coin", "wallet", "trade", "trading", "order", "price", "limit", "market",
  "issue", "problem", "error", "trouble", "fail", "failed", "delay", "delayed", 
  "fix", "resolve", "solution", "reset", "password", "OTP", "2FA", "KYC", "Passkey", "code", "link", 
  "login", "access", "security", "protect", "policy",
  "today", "tomorrow", "yesterday", "now", "soon", "time", "date", "minute", 
  "hour", "day", "business", "working", "currently", "coordinate", "relevant", "doing", "moment", "patience"
];

fetch(chrome.runtime.getURL('thai_dictionary.csv'))
  .then(res => res.text())
  .then(text => {
    const lines = text.split(/\r?\n/);
    lines.forEach(line => {
      const word = line.split(',')[0].trim().replace(/^"|"$/g, '');
      if (word && word !== 'word') thaiDict.add(word);
    });
  })
  .catch(err => console.log('CSV load error:', err));


function convertText(text) {
  const hasEnglish = /[a-zA-Z]/.test(text); 
  return text.split('').map(char => {
    if (hasEnglish) {
      return enToTh[char] || char;
    } else {
      return thToEn[char] || char;
    }
  }).join('');
}

function isValidWord(word) {
  if (!word) return true;
  const cleanWord = word.replace(/[^a-zA-Z0-9ก-ฮะ-์]/g, '').trim();
  if (!cleanWord) return true;

  if (/[ก-ฮ]/.test(cleanWord)) {
    return thaiDict.has(cleanWord);
  } else if (/[a-zA-Z0-9]/.test(cleanWord)) {
    return englishDict.some(dictWord => dictWord.toLowerCase() === cleanWord.toLowerCase());
  }
  return true;
}

function processSwitch(text) {
  return convertText(text);
}

function highlightUnknownWords(element) {
  const oldNotice = document.getElementById('extension-spell-notice');
  if (oldNotice) oldNotice.remove();

  const text = element.value || element.innerText || '';
  const words = text.split(/\s+/);
  let unknownWords = [];

  words.forEach(word => {
    const trimWord = word.trim();
    if (trimWord && !isValidWord(trimWord)) {
      unknownWords.push(trimWord);
    }
  });

  if (unknownWords.length > 0) {
    showNoticeBanner(element, unknownWords);
  }
}

function showNoticeBanner(element, unknownWords) {
  const rect = element.getBoundingClientRect();
  const banner = document.createElement('div');
  banner.id = 'extension-spell-notice';
  banner.style.cssText = `
    position: fixed !important;
    top: ${rect.bottom + 6}px !important;
    left: ${rect.left}px !important;
    background: #fff0f0 !important;
    border: 2px solid #ff4d4f !important;
    border-radius: 6px !important;
    padding: 8px 14px !important;
    font-size: 14px !important;
    color: #cf1322 !important;
    z-index: 2147483647 !important;
    box-shadow: 0 4px 12px rgba(0,0,0,0.2) !important;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
  `;

  banner.innerHTML = `
    ⚠️ <strong>พบคำสงสัยสะกดผิด:</strong> 
    <span style="text-decoration: underline wavy #ff0000; font-weight: bold; font-size: 15px;">${unknownWords.join(', ')}</span>
    <button id="close-notice-btn" style="margin-left: 12px; background: #ff4d4f; color: white; border: none; border-radius: 4px; padding: 2px 8px; cursor: pointer;">✕</button>
  `;

  document.body.appendChild(banner);

  document.getElementById('close-notice-btn').onclick = () => banner.remove();
  setTimeout(() => { if (banner) banner.remove(); }, 10000);
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "SWITCH_KEYBOARD") {
    const activeEl = document.activeElement;

    if (activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA')) {
      const start = activeEl.selectionStart;
      const end = activeEl.selectionEnd;
      const selectedText = activeEl.value.substring(start, end);

      if (selectedText) {
        const converted = processSwitch(selectedText);
        activeEl.setRangeText(converted, start, end, 'select');
        activeEl.dispatchEvent(new Event('input', { bubbles: true }));
        activeEl.dispatchEvent(new Event('change', { bubbles: true }));

        setTimeout(() => highlightUnknownWords(activeEl), 150);
      }
    } else {
      const sel = window.getSelection();
      if (sel && sel.rangeCount > 0) {
        const selectedText = sel.toString();
        if (selectedText) {
          const converted = processSwitch(selectedText);
          document.execCommand('insertText', false, converted);
        }
      }
    }
  }
});